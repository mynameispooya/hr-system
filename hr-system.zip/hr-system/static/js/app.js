/* ===== ابزارهای مشترک API ===== */
const API = {
    async get(url) {
        const r = await fetch(url);
        const d = await r.json();
        if (!r.ok) throw new Error(d.error || 'خطایی رخ داد');
        return d;
    },
    async post(url, body) {
        const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
        const d = await r.json();
        if (!r.ok) throw new Error(d.error || 'خطایی رخ داد');
        return d;
    },
    async put(url, body) {
        const r = await fetch(url, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
        const d = await r.json();
        if (!r.ok) throw new Error(d.error || 'خطایی رخ داد');
        return d;
    },
    async del(url) {
        const r = await fetch(url, { method: 'DELETE' });
        const d = await r.json();
        if (!r.ok) throw new Error(d.error || 'خطایی رخ داد');
        return d;
    },
    async upload(url, formData) {
        const r = await fetch(url, { method: 'POST', body: formData });
        const d = await r.json();
        if (!r.ok) throw new Error(d.error || 'خطایی رخ داد');
        return d;
    }
};

/* ===== توست اعلان ===== */
function toast(msg, type = 'success') {
    const c = document.getElementById('toast-container');
    if (!c) return;
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.innerHTML = `<span>${msg}</span><button onclick="this.parentElement.remove()">&times;</button>`;
    c.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 4500);
}

/* ===== مودال ===== */
function openModal(id) {
    const m = document.getElementById(id);
    if (m) { m.classList.add('active'); document.body.style.overflow = 'hidden'; }
}
function closeModal(id) {
    const m = document.getElementById(id);
    if (m) { m.classList.remove('active'); document.body.style.overflow = ''; }
}

/* ===== برچسب‌ها ===== */
function actionLabel(a) {
    const m = {
        create_section: 'ایجاد بخش', delete_section: 'حذف بخش',
        add_employees: 'افزودن کارکنان', upload_employees: 'آپلود اکسل',
        delete_employee: 'حذف کارمند', transfer: 'انتقال مستقیم',
        transfer_initiated: 'درخواست انتقال', transfer_accepted: 'پذیرش انتقال',
        transfer_rejected: 'رد انتقال', settlement: 'تسویه',
        create_user: 'ایجاد کاربر', update_user: 'ویرایش کاربر',
        delete_user: 'حذف کاربر', change_password: 'تغییر رمز'
    };
    return m[a] || a;
}
function statusLabel(s) {
    const m = { pending: 'در انتظار تایید', accepted: 'پذیرفته شده', rejected: 'رد شده', completed: 'تکمیل شده' };
    return m[s] || s;
}
function statusClass(s) {
    const m = { pending: 'pending', accepted: 'accepted', rejected: 'rejected', completed: 'completed' };
    return m[s] || '';
}

/* ===== رویدادهای کلی ===== */
document.addEventListener('click', e => {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
        document.body.style.overflow = '';
    }
});
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
        document.body.style.overflow = '';
    }
});